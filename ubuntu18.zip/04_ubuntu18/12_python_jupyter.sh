#!/bin/bash

function init1_python_02() {
    mkdir -p ~/.jupyter/
    /bin/cp -f ./jupyter_notebook_config.py ~/.jupyter/
}

function init1_python_03() {
    conda search tensorflow
    conda install -y tensorflow plotly keras
    conda update jupyter_core jupyter_client
    conda list |egrep "tensorflow|keras|plotly"
    conda -V
}

function jupyter_start() {
    cp jupyter.service.txt /etc/init.d/jupyter.service
    chmod +x /etc/init.d/jupyter.service
    /etc/init.d/jupyter.service start

    netstat -anp|grep 8888
}

init1_python_02
jupyter_start
init1_python_03
