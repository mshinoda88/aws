#!/bin/bash
# 05_init_syslog.sh

apt-get install -y rsyslog

cat /etc/rsyslog.conf
/etc/init.d/rsyslog restart

# 自動起動設定
systemctl enable rsyslog 
systemctl list-unit-files --type=service|grep rsyslog


