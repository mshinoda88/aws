#!/bin/bash

sudo apt-get install automake autotools-dev g++ git libcurl4-gnutls-dev libfuse-dev libssl-dev libxml2-dev make pkg-config -y

#s3fsをインストール
git clone https://github.com/s3fs-fuse/s3fs-fuse.git
cd s3fs-fuse
./autogen.sh
./configure
make
sudo make install

#IAM access keyを保存
#echo <Access Key ID>:<Secret Access Key> | sudo tee -a /etc/passwd-s3fs
echo "AKIAIWU3V2TI735CPV6Q:LKwa5MSPrKXeCQ+dQ4jA0SLLQloXHxbXKLfy9Y+a" | sudo tee -a /etc/passwd-s3fs
sudo chmod 640 /etc/passwd-s3fs


