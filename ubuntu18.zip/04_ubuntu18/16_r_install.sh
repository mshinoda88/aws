#!/bin/bash

## conda@Ubuntu16.04 環境に R の glmmMLパッケージを入れる手順 ##
# まずはコンパイラを入れる。
sudo apt-get install build-essential

# conda 環境にもコンパイラを導入。
conda install gxx_linux-64
conda install gfortran_linux-64
conda update -n base conda

apt install -y r-base-core
conda install -c r r-essentials
echo "# R"
# 'q()' と入力すれば R を終了します。
# condaのライブラリ群もアップデートしておく。
echo '> 37: Japan (Tokyo) [https]'

echo "> update.packages()"

# glmmML を導入する
echo '> install.packages("glmmML")'
echo '>q()'
echo '>Save workspace image? [y/n/c]: y'
