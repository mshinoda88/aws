#!/bin/bash
# 01_init_os.sh

apt-get update
apt-get dist-upgrade -y

apt-get install -y sysv-rc-conf
apt-get install -y wcstools
apt-get install -y openssh-server
apt-get install -y aptitude
apt-get install -y ntp
apt-get install -y logrotate
apt-get install -y tree
apt-get install -y git
apt-get install -y p7zip-full unzip
apt-get install -y nkf

touch ~/.vimrc
echo "set nocompatible" >> ~/.vimrc
echo "set backspace=indent,eol,start" >> ~/.vimrc

cat ~/.vimrc

