#!/bin/bash

mkdir -p /mnt/s301

Bucket_Name=dsc-s3-nttdata-20181108
Mount_Point=/mnt/s301
sUID=0
sGID=0
sudo /usr/local/bin/s3fs ${Bucket_Name} ${Mount_Point} -o rw,allow_other,uid=${sUID},gid=${sGID},default_acl=public-read

