#!/bin/bash

# ビルドに必要なコンパイラ類
apt install build-essential zlib1g-dev libssl-dev libffi-dev -y
apt install libbz2-dev libreadline-dev libsqlite3-dev -y
gcc --version
#gcc (Ubuntu 7.4.0-1ubuntu1~18.04.1) 7.4.0
#Copyright (C) 2017 Free Software Foundation, Inc.
#This is free software; see the source for copying conditions.  There is NO
#warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

make --version
#GNU Make 4.1
#このプログラムは x86_64-pc-linux-gnu 用にビルドされました
#Copyright (C) 1988-2014 Free Software Foundation, Inc.
#ライセンス GPLv3+: GNU GPL バージョン 3 以降 <http://gnu.org/licenses/gpl.html>
#これはフリーソフトウェアです: 自由に変更および配布できます.
#法律の許す限り、　無保証　です.

pyenv global 3.7.3
pyenv rehash
python --version

pyenv versions
#* 3.7.3 (set by /opt/pyenv/version)

which pip
#/opt/pyenv/shims/pip

# pipを最新の状態へ更新します。
pip install --upgrade setuptools
pip install --upgrade pip

pip --version
#pip 19.1.1 from /opt/pyenv/versions/3.7.3/lib/python3.7/site-packages/pip (python 3.7)


# jupyter のインストール
pip install numpy
pip install scipy
pip install matplotlib
pip install Pillow
pip install ipython[all]
pip install jupyter

mkdir -p /opt/gcp_work/key
export GOOGLE_APPLICATION_CREDENTIALS=/opt/gcp_work/key/d-da-project-dtc-camp-geo.json
