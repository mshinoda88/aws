#!/bin/bash
# 04_init_ntp.sh

apt-get install -y ntp
FILE_CONF=/etc/ntp.conf
FILE_NAME=`filename /etc/ntp.conf`


# オリジナルファイルのバックアップ
/bin/cp -pr ${FILE_CONF} ${FILE_CONF}.org

cat ${FILE_CONF} |sed -e s/^pool/#pool/g > ./${FILE_NAME}
cat <<_EOT_ >> ./${FILE_NAME}

# 同期をとるサーバーを指定
server ntp1.jst.mfeed.ad.jp iburst
server ntp2.jst.mfeed.ad.jp iburst
server ntp3.jst.mfeed.ad.jp iburst

# 時刻同期を許可する範囲を追記
restrict 10.0.0.0 mask 255.255.255.0 nomodify notrap
_EOT_

/bin/cp -pr ./${FILE_NAME} ${FILE_CONF}

# NTP起動
/etc/init.d/ntp restart

# 自動起動設定
systemctl enable ntp
systemctl list-unit-files --type=service |grep ntp

# 動作確認
ntpq -p

