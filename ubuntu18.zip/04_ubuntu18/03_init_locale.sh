#!/bin/bash
# 03_init_locale.sh

# ssh install
apt-get install -y openssh-server

# sshd 起動設定
systemctl enable ssh.service
systemctl start ssh.service

# ipv6設定
# 以下無効にする場合の設定
echo "options ipv6 disable=1" >  /etc/modprobe.d/disable-ipv6.conf

# ロケール設定
# (ja_JP.UTF-8を選ぶ)
apt install -y aptitude
aptitude install -y language-pack-ja
export LANG=ja_JP.UTF-8
update-locale LANG=ja_JP.UTF-8
#dpkg-reconfigure locales

# Timezoneの設定
# （Asia/Tokyoを選ぶ)
#dpkg-reconfigure tzdata
sudo timedatectl set-timezone Asia/Tokyo
timedatectl

# ロケール確認
echo "--- 1:localectl ---"
localectl
echo "--- 2:locale ---"
locale
echo "--- 3:date ---"
date

# /usr/share/zoneinfo/Asia/Tokyo から /etc/localtime にリンクを張る
ln -sf /usr/share/zoneinfo/Asia/Tokyo /etc/localtime

# font のインストール
apt-get install -y fonts-ipafont


echo ""
echo "#######################################"
echo "rebootして再ログインしてください。"
echo "# reboot"
echo "#######################################"

