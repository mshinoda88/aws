#!/bin/bash
# 02_os_tuning.sh

cat <<_EOT_ > ./sysctl.conf
# ファイルディスクリプタの最大数。
# 外部からのアクセスが多い場合には多く設定しておかないと
# アクセス遅延などの問題が発生する。
fs.file-max = 99002

# メモリのスワップの度合い。
# 値が高いほどスワップの頻度が高くなる。
vm.swappiness = 1

# サーバ内部で使用するポート番号の範囲。
# リバースプロキシなどで使用している場合には、
# 1024から65535とする。
net.ipv4.ip_local_port_range = 10000 61000

# TCPの受信バッファサイズの最大値。
net.core.rmem_max = 16777216

# TCPの送信バッファサイズの最大値。
net.core.wmem_max = 16777216

# TCPの受信バッファサイズのデフォルト値。
net.core.rmem_default = 16777216

# TCPの送信バッファサイズのデフォルト値。
net.core.wmem_default = 16777216

# 補助バッファサイズの最大値。
net.core.optmem_max = 40960

# TCPの受信バッファサイズ。
# 左から最小値、デフォルト値、最大値。
net.ipv4.tcp_rmem = 4096 87380 16777216

# TCPの送信バッファサイズ。
# 左から最小値、デフォルト値、最大値。
net.ipv4.tcp_wmem = 4096 65536 16777216

# パケット受信時にキューにつなぐことのできる
# パケットの最大数。
net.core.netdev_max_backlog = 50000

# SYNに対するSYN/ACKの応答待ちに使うソケットの最大数。
net.ipv4.tcp_max_syn_backlog = 30000

# TIME_WAIT 状態にあるソケットの最大数。
net.ipv4.tcp_max_tw_buckets = 2000000

# TCPのTIME_WAITを再利用するかどうか。TIME_WAITはソケット
# オープン状態であるため、多数残存するとパフォーマンスに
# 大きな影響が出る。
net.ipv4.tcp_tw_reuse = 1

# TCPのTIME_WAITの再利用を高速化するかどうか。
net.ipv4.tcp_tw_recycle = 1

# TCPのFINを送信してからのタイムアウト時間。
net.ipv4.tcp_fin_timeout = 10

# 通信がアイドル状態になった後にスロースタートさせるか
# どうか。
net.ipv4.tcp_slow_start_after_idle = 0

# UDPの受信バッファサイズの最小値。
net.ipv4.udp_rmem_min = 8192

# UDPの送信バッファサイズの最小値。
net.ipv4.udp_wmem_min = 8192

# 全てのインターフェイスで全てのIPv4?ICMPリダイレクト
# パケットを送信させるかどうか。
net.ipv4.conf.all.send_redirects = 0

# 全てのインターフェイスで全てのIPv4?ICMPリダイレクト
# パケットを受信させるかどうか。
net.ipv4.conf.all.accept_redirects = 0

# ソースルーティングオプションが付加されたパケットを
# 許可するかどうか。
net.ipv4.conf.all.accept_source_route = 0

# 偽装、不正パケットのリダイレクトをログに記録するかどうか。
net.ipv4.conf.all.log_martians = 1

# ipv6 disabled
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
_EOT_

/bin/cp -pr ./sysctl.conf /etc/sysctl.conf
cat /etc/sysctl.conf

